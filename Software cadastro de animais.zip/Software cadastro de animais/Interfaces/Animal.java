package Interfaces;
public interface Animal {

    public void comunicar();
    public void andar();
    public void reproduzir();
    
}
